/**
 * A24by7 Authentication Database Migration Runner
 * Target: MySQL 8+
 *
 * The GoDaddy Hosted Database is already provisioned.
 * This script only applies and verifies the application schema.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import mysql from 'mysql2/promise';
import { env } from '../config/env.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runMigration() {
  const targetDb = env.db.database || 'a24by7_dev';

  console.log(
    `[MIGRATE] Connecting to MySQL database "${targetDb}"...`
  );

  const connection = await mysql.createConnection({
    host: env.db.host,
    port: env.db.port,
    user: env.db.user,
    password: env.db.password,
    database: targetDb,
    connectTimeout: env.db.connectionTimeoutMillis,
  });

  try {
    console.log(
      `[MIGRATE] Connected to "${targetDb}". Applying authentication schema...`
    );

    const migrationPath = path.join(
      __dirname,
      'migrations',
      '001_create_auth_schema.sql'
    );

    const migrationSql = fs.readFileSync(migrationPath, 'utf8');

    /*
     * The migration contains multiple CREATE TABLE statements.
     * multipleStatements is enabled ONLY for this migration connection.
     * The normal application database pool does not enable it.
     */
    const migrationConnection = await mysql.createConnection({
      host: env.db.host,
      port: env.db.port,
      user: env.db.user,
      password: env.db.password,
      database: targetDb,
      connectTimeout: env.db.connectionTimeoutMillis,
      multipleStatements: true,
    });

    try {
      await migrationConnection.query(migrationSql);
    } finally {
      await migrationConnection.end();
    }

    console.log(
      '[MIGRATE] Migration "001_create_auth_schema.sql" applied successfully!'
    );

    // =========================================================================
    // Verify Tables
    // =========================================================================

    console.log('\n[MIGRATE] Verifying database schema & tables...');

    const [tables] = await connection.execute(
      `
      SELECT TABLE_NAME AS table_name
      FROM information_schema.tables
      WHERE table_schema = ?
        AND table_type = 'BASE TABLE'
        AND table_name IN (
          'users',
          'email_verification_tokens',
          'password_reset_tokens',
          'sessions'
        )
      ORDER BY table_name;
      `,
      [targetDb]
    );

    const foundTables = tables.map((row) => row.table_name);

    console.log('[MIGRATE] Verified Tables:', foundTables);

    const requiredTables = [
      'users',
      'email_verification_tokens',
      'password_reset_tokens',
      'sessions',
    ];

    const missingTables = requiredTables.filter(
      (table) => !foundTables.includes(table)
    );

    if (missingTables.length > 0) {
      throw new Error(
        `Schema verification failed. Missing tables: ${missingTables.join(', ')}`
      );
    }

    // =========================================================================
    // Verify Primary Keys
    // =========================================================================

    const [primaryKeys] = await connection.execute(
      `
      SELECT
        kcu.TABLE_NAME AS table_name,
        kcu.COLUMN_NAME AS column_name
      FROM information_schema.table_constraints tc
      JOIN information_schema.key_column_usage kcu
        ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
        AND tc.TABLE_SCHEMA = kcu.TABLE_SCHEMA
        AND tc.TABLE_NAME = kcu.TABLE_NAME
      WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
        AND tc.TABLE_SCHEMA = ?
        AND tc.TABLE_NAME IN (
          'users',
          'email_verification_tokens',
          'password_reset_tokens',
          'sessions'
        )
      ORDER BY kcu.TABLE_NAME, kcu.ORDINAL_POSITION;
      `,
      [targetDb]
    );

    console.log('[MIGRATE] Verified Primary Keys:');

    primaryKeys.forEach((row) => {
      console.log(
        `  - ${row.table_name}.${row.column_name} (PK)`
      );
    });

    // =========================================================================
    // Verify Foreign Keys
    // =========================================================================

    const [foreignKeys] = await connection.execute(
      `
      SELECT
        kcu.TABLE_NAME AS table_name,
        kcu.COLUMN_NAME AS column_name,
        kcu.REFERENCED_TABLE_NAME AS foreign_table_name,
        kcu.REFERENCED_COLUMN_NAME AS foreign_column_name,
        rc.DELETE_RULE AS delete_rule
      FROM information_schema.key_column_usage kcu
      JOIN information_schema.referential_constraints rc
        ON rc.CONSTRAINT_SCHEMA = kcu.CONSTRAINT_SCHEMA
        AND rc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
        AND rc.TABLE_NAME = kcu.TABLE_NAME
      WHERE kcu.CONSTRAINT_SCHEMA = ?
        AND kcu.TABLE_NAME IN (
          'email_verification_tokens',
          'password_reset_tokens',
          'sessions'
        )
        AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
      ORDER BY kcu.TABLE_NAME, kcu.COLUMN_NAME;
      `,
      [targetDb]
    );

    console.log('[MIGRATE] Verified Foreign Keys:');

    foreignKeys.forEach((row) => {
      console.log(
        `  - ${row.table_name}.${row.column_name} -> ` +
        `${row.foreign_table_name}.${row.foreign_column_name} ` +
        `(${row.delete_rule})`
      );
    });

    // =========================================================================
    // Verify Indexes
    // =========================================================================

    const [indexes] = await connection.execute(
      `
      SELECT
        TABLE_NAME AS table_name,
        INDEX_NAME AS index_name,
        COLUMN_NAME AS column_name,
        NON_UNIQUE AS non_unique
      FROM information_schema.statistics
      WHERE TABLE_SCHEMA = ?
        AND TABLE_NAME IN (
          'users',
          'email_verification_tokens',
          'password_reset_tokens',
          'sessions'
        )
      ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;
      `,
      [targetDb]
    );

    console.log('[MIGRATE] Verified Indexes:');

    indexes.forEach((row) => {
      console.log(
        `  - ${row.table_name}: ${row.index_name} (${row.column_name})`
      );
    });

    // =========================================================================
    // Verification Summary
    // =========================================================================

    console.log('\n[MIGRATE] Schema verification completed successfully.');

    return {
      success: true,
      tables: foundTables,
      primaryKeys,
      foreignKeys,
      indexes,
    };
  } finally {
    await connection.end();
  }
}

async function main() {
  try {
    await runMigration();

    console.log(
      '\n[MIGRATE] ===================================================='
    );
    console.log(
      '[MIGRATE] ALL 4 AUTHENTICATION TABLES SUCCESSFULLY VERIFIED!'
    );
    console.log(
      '[MIGRATE] ===================================================='
    );
  } catch (err) {
    console.error(
      '\n[MIGRATE_FATAL] Migration failed:',
      err.message
    );

    process.exit(1);
  }
}

main();